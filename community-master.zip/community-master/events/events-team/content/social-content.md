# Social Event Content Handbook

## Overview

The Social Event Content Lead is responsible for arranging and recruiting activities and/or displays during the Social Event for the Summit.  The content should celebrate contributing to Kubernetes and/or help contributors meet and enjoy time together. These may include slide shows, presentations, guided socialization exercises, or even music or art.   

## Skills and Qualifications

TODO  

## Activities  

WIP

## Time Commitment

TODO

## Instructions and Tips for Specific Tasks
