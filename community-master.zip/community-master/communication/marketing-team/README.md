Future home for all things marketing team for contributor experience

TODO: Add overview (ties to contribex charter, what we do, how, why), other resources

# Core Marketing Team roles

| Role | Handbook | Notes |
| --- | --- | --- |
| Blogger(s) | TODO | alex vonguard has taken interest |
| Social Media | TODO | for future contributor channels |
| Editor | TODO | unsure if this will be a position but could be good for making sure we are using the style guide and ensuring a consistent tone and brand |
| Designer | TODO | help us with thumbnail graphics, digital assets, infographics, contributor site |

# Length of position
TODO

# How to be on this team
Self nominations will start when we add more clarity here. Self nominations should
first be considered from OWNERs file contributors and then open up to a criteria //TODO
