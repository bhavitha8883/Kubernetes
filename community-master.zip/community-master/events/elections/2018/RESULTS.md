# Results of the 2018 Steering Committee Election

- Number of seats open: 3 (2 year term)
- Number of eligible voters: 692
- Number of votes cast: 307
- Turnout: 44%

[Raw ballot data](BALLOTS.csv)

## Results

The final ranking, using the "Schulze" Condorcet completion, is as follows:

1. Aaron Crickenberger
2. Timothy St. Clair
3. Davanum Srinivas
4. Nikhita Raghunath
5. Kris Nova
6. Quinton Hoole
7. Stephen Augustus
8. Tim Pepper

## Winners

The winners of the open seats are as follows:

Two year term:

1. Aaron Crickenberger
2. Timothy St. Clair
3. Davanum Srinivas