# Awards Ceremony Handbook

## Overview

The Awards Ceremony coordinators collect information on desired awards and nominees from the community, determine the form and schedule for the community awards, and ensure that awarding community members and award recipients are present for the ceremony.  They also source award trophies or tokens.  Because of the nature of these awards, these activities need to be carried out semi-confidentially in order to ensure that award recipients are not prematurely notified.

## Skills and Qualifications

TODO  

## Activities  

WIP

## Time Commitment

TODO

## Instructions and Tips for Specific Tasks
