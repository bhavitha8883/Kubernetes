# Troubleshoot Running Pods

*   Status: Superseded
*   Version: N/A
*   Implementation Owner: @verb

The Troubleshooting Running Pods proposal has moved to the
[Ephemeral Containers KEP](https://git.k8s.io/enhancements/keps/sig-node/20190212-ephemeral-containers.md).
