This file has moved to https://git.k8s.io/community/communication/youtube/youtube-guidelines.md.

This file is a placeholder to preserve links. Please remove after 2019-11-11.
