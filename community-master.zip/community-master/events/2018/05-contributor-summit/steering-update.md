# Steering Committee Update
**Leads:** pwittrock, timothysc  
**Thanks to our notetaker:** tpepper

* incubation is deprecated, "associated" projects are a thing
* WG are horizontal across SIGs and are ephemeral.  Subprojects own a piece
  of code and relate to a SIG.  Example: SIG-Cluster-Lifecycle with
  kubeadm, kops, etc. under it.
* SIG charters: PR a proposed new SIG with the draft charter.  Discussion
  can then happen on GitHub around the evolving charter.  This is cleaner
  and more efficient than discussing on mailing list.
* K8s values doc updated by Sarah Novotny
* changes to voting roles and rules are in the works
