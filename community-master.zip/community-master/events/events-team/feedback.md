We have been collecting feedback in some shape or form since we started doing
Contributor Summits (fka Developer Summits) from both attendees as well as our
awesome set of volunteers. The feedback is an integral part of our content
creation and overall experience of the event. This doc captures these for
historical and future planning purposes.

Thanks to all who have provided feedback in the past.

####
[2016 feedback]  

#### Austin  
[2017 feedback]  

#### Copenhagen  
[2018 EU feedback]    
[2018 EU retro]  

#### Shanghai  
TODO  

#### Seattle  
[2018 feedback]  
[2018 retro]  

#### Barcelona  
TODO  



[2016 feedback]: https://docs.google.com/spreadsheets/d/1W443ToSJGvk5O2ah1bOC6OUM4F7zsBoJRtq2qbLC36E/edit?usp=sharing
[2017 feedback]: https://docs.google.com/spreadsheets/d/1NNfd4O4mcwGaJJuw1QS9PUEBF08u2QlaW54t5IuJEFc/edit?usp=sharing
[2018 EU feedback]: https://docs.google.com/spreadsheets/d/1Bev8BthgC5OBtak5BDR23lG2eYs3b8UEngoewDyEsnc/edit?usp=sharing
[2018 EU retro]: https://docs.google.com/document/d/1XyjCDFiEx06TkD4vDkci00h0uZR9OVNnKd6MxVo_bAo/edit
[2018 feedback]: https://docs.google.com/spreadsheets/d/1VXwAYo8sJQk1amrayUaYRN5Ly5cYi-t2Yw355veRcDs/edit?usp=sharing
[2018 retro]: https://docs.google.com/document/d/1lonVMIO15xZoxZtX5Gr5N-Wb5GtDY5lGnjKgrfNEAyU/edit?usp=sharing&urp=gmail_link
