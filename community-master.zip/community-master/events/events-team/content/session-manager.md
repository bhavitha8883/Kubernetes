# Programmed Sessions Handbook

## Overview

The Programmed Sessions lead recruits, selects, and schedules planned short-form sessions for the Contributor Summit.  These sessions cover topics of interest to regular contributors, such as contribution tasks, project changes, discussions of architectural changes and features, mentorship and sustainability, or testing and conformance.

This is distinct from Contributor Workshops (which are long-form, always-interactive sessions), and an Unconference, which are sessions NOT selected in advance.  If the Summit has those types of sessions as well, the PS team will coordinate with other teams to work out a balanced schedule.

## Skills and Qualifications

TODO  

## Activities  

WIP

## Time Commitment

TODO

## Instructions and Tips for Specific Tasks
