**Per the [Template & Instruction Document](https://docs.google.com/document/d/1ncrfiVEy_WELqZaNdYOX0_9uuKzuTikgVC-mz2Izsc4/edit?usp=sharing), 
upload your session notes here with the name format**:

*HHMM-HHMM_SESSIONTITLE.md*

where HHMM is the time in 24-hour format.
