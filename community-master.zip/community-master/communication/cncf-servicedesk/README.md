## CNCF Service Desk

This OWNERs file lists the people who have access to file tickets with the [CNCF Service Desk](https://github.com/cncf/servicedesk) on behalf of the Kubernetes project.
