# Contributor Workshops Handbook

## Overview

The Contributor Workshop team recruits, selects, and schedules "advanced" workshops for current Kubernetes contributors to improve their skills during the Contributor Summit.  Such workshops might include hands-on demonstrations of build or testing tasks, live interactive reviews of PRs, KEPs, API changes, or similar, documentation writing, or other long-form activities involving some hands-on-keyboard participation.  

This is distinct from the [New Contributor and Intermediate Contributor workshops](./new-contributor.md), although the CW team will work with that team.

## Skills and Qualifications

TODO  

## Activities  

WIP

## Time Commitment

TODO

## Instructions and Tips for Specific Tasks
