  
Status: Draft  
Created: 2018-04-09   /  Last updated: 2019-03-01
Author: bsalamat  
Contributors: misterikkit

---

The scheduling framework design has moved to https://github.com/kubernetes/enhancements/blob/master/keps/sig-scheduling/20180409-scheduling-framework.md
