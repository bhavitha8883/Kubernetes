# Results of the 2017 Steering Committee Election

Number of seats open: 3 (2 year term), 3 (1 year term)

Number of eligible voters: 392

Number of votes cast: 309

Turnout: 78.8%

[Raw ballot data](BALLOTS.csv)

## Results

The final ranking, using the "Schulze" Condorcet completion, is as follows:

1. Derek Carr
2. Michelle Noorali
3. Phillip Wittrock
4. Michael Rubin
5. Timothy St. Clair
6. Quinton Hoole
7. Aaron Crickenberger
8. Caleb Miles
9. Jaice Singer DuMars
10. Kris Nova
11. Justin Santa Barbara
12. Alex Pollitt
13. Sebastien Goasguen
14. Ihor Dvoretskyi
15. Adnan Abdulhussein
16. Ilya Dmitrichenko
17. Matt Farina
18. Aaron Schlesinger
19. Rob Hirschfeld
20. Doug Davis

According to the limits on company representation, Google would be
over-represented with this result, so Michael Rubin must be excluded.

## Winners

The winners of the open seats are as follows:

Two year term:
1. Derek Carr
2. Michelle Noorali
3. Phillip Wittrock

One year term:
1. Timothy St. Clair
2. Quinton Hoole
3. Aaron Crickenberger
